package qxxt;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;

import java.security.MessageDigest;

public class QianxunMessage {

	public static void main(String[] args) {
		PostMethod postMethod = new PostMethod("http://api.dzd.com/v4/sms/send.do");
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddhhmmss");
		String timeStamp = format.format(new Date());// 时间戳
		String uid = "69";// 账户id
		String key = "14bfa6bb14875e45bba028a21ed38046";// key
		
		// 设置参数
		postMethod.addParameter("uid", uid);
		postMethod.addParameter("timestamp", timeStamp);
		postMethod.addParameter("sign", getSign(uid, key, timeStamp));
		postMethod.addParameter("mobile", "18617052312");
		postMethod.addParameter("text", "【云九网络】您的验证码是10025");
		postMethod.addParameter("iid", "423");// 格子编码id
		HttpClient httpClient = new HttpClient();
		httpClient.getParams().setParameter(
				HttpMethodParams.HTTP_CONTENT_CHARSET, "utf-8");
		try {
			// post提交发送短信
			httpClient.executeMethod(postMethod);
			System.out.println(postMethod.getResponseBodyAsString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 生成签名
	 * 
	 * @param account
	 * @param key
	 * @param timeStamp
	 * @return
	 */
	private static String getSign(String account, String key, String timeStamp) {
		// 账户 + key + 时间戳 MD5加密 
		return string2MD5(account + key + timeStamp);
	}
	

	/**
	 * MD5加密
	 * 
	 * @param inStr
	 * @return
	 */
	public static String string2MD5(String inStr) {
		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
			return "";
		}
		char[] charArray = inStr.toCharArray();
		byte[] byteArray = new byte[charArray.length];

		for (int i = 0; i < charArray.length; i++)
			byteArray[i] = (byte) charArray[i];
		byte[] md5Bytes = md5.digest(byteArray);
		StringBuffer hexValue = new StringBuffer();
		for (int i = 0; i < md5Bytes.length; i++) {
			int val = ((int) md5Bytes[i]) & 0xff;
			if (val < 16)
				hexValue.append("0");
			hexValue.append(Integer.toHexString(val));
		}
		return hexValue.toString();
	}
}
